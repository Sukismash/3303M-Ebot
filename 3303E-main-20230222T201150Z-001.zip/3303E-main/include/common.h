#pragma once

#include "main.h"
#include "pros/misc.hpp"

extern Controller controller;

const auto pdelay = pros::delay;