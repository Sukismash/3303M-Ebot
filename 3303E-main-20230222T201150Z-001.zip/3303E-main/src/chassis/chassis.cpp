#include "chassis.hpp"

#include "main.h"

#include "pros/misc.h"
#include "constants.hpp"

namespace src::Chassis {

    // Driver Control
    std::shared_ptr<ChassisController> chassis =
        ChassisControllerBuilder()
            .withMotors(left_chassis, right_chassis)
            .withDimensions(AbstractMotor::gearset::blue, {{3.25_in, 12.75_in}, imev5BlueTPR})
            .build();
    
    void initialize() {
        left_chassis.setBrakeMode(AbstractMotor::brakeMode::coast);
        right_chassis.setBrakeMode(AbstractMotor::brakeMode::coast);
    }

    void update() {}

    void act() {
        Chassis::chassis->getModel()->tank(
            controller.getAnalog(ControllerAnalog::leftY),
            controller.getAnalog(ControllerAnalog::rightY)
        );
    }

    pros::Imu imuSensor = pros::Imu(IMU_PORT);

    // curves + straight
    void movePID(float leftTarget, float rightTarget, int ms, float maxV) {
        float degreesR = ((rightTarget/(pi*WHEEL_DIAMETER)) * 360) / DRIVE_GEAR_RATIO;
        float degreesL = ((leftTarget/(pi*WHEEL_DIAMETER)) * 360) / DRIVE_GEAR_RATIO;

        // Create PID controllers for each side of the chassis
        auto drivePIDL = okapi::IterativeControllerFactory::posPID(P_GAIN, I_GAIN, D_GAIN);
        auto drivePIDR = okapi::IterativeControllerFactory::posPID(P_GAIN, I_GAIN, D_GAIN);
        
        // Reset Chassis sensors
        chassis->getModel()->resetSensors();
        
        // Initialize loop variables
        int timer = 0;
        float errorL;
        float errorR;
        float powerL;
        float powerR;

        // Within time limit, increment PID loop
        while (timer < ms) {
            errorL = degreesL + chassis->getModel()->getSensorVals()[0];
            errorR = degreesR + chassis->getModel()->getSensorVals()[1];
            powerL = drivePIDL.step(errorL);
            powerR = drivePIDR.step(errorR);
            chassis->getModel()->tank(powerL * maxV, powerR * maxV);
            pros::delay(10);
            timer += 10;
        }

        chassis->getModel()->tank(0, 0);
    }

    // no imu
    void turnPID(float degrees, bool CW, float maxV) {
        
        float turningCircleCircumference = M_PI * WHEEL_TRACK;
        float wheelDistance = (degrees / 360.0f) * (turningCircleCircumference / 2.0f);

        // Turns should always take at least 1 second
        int turnTimer = 1500;
        
        if (!CW) {
            movePID(wheelDistance, -1 * wheelDistance, turnTimer, maxV);
        } else {
            movePID(-1 * wheelDistance, wheelDistance, turnTimer, maxV);
        }
    }

    //IMU
    void gyroPID(int degree, int ms) {

        imuSensor.tare_rotation();
        int timer = 0;
        float prevError = 0;
        float integral = 0;
        src::Chassis::controller.clear();
        while (timer < ms) {
            float sensorVal = imuSensor.get_rotation();
            pros::screen::print(pros::E_TEXT_LARGE, 0, "gyro: %f", sensorVal);
            float error = degree - sensorVal;
            float derivative = error - prevError;
            prevError = error;
            integral += error;
            float power = (P_GAIN_TURN * error) + (I_GAIN_TURN * integral) + (D_GAIN_TURN * derivative);
                
            chassis->getModel()->tank(power, -1 * power);

            timer += 10;
            pros::delay(10);

        }
        chassis->getModel()->tank(0, 0);
    }

    //graph for PID 
    void lv_ex_chart_1(float kP, float kI, float kD, int ms)
    {
        /*Create a chart*/
        lv_obj_t * chart;
        chart = lv_chart_create(lv_scr_act(), NULL);
        lv_obj_set_size(chart, 400, 200);
        lv_obj_align(chart, NULL, LV_ALIGN_CENTER, 0, 0);
        lv_chart_set_type(chart, LV_CHART_TYPE_LINE);   /*Show lines and points too*/
        int timer = 0;

        /*Add two data series*/
        lv_chart_series_t * ser1 = lv_chart_add_series(chart, LV_COLOR_RED);
        lv_chart_series_t * ser2 = lv_chart_add_series(chart, LV_COLOR_GREEN);
        lv_chart_series_t * ser3 = lv_chart_add_series(chart, LV_COLOR_BLUE);
        lv_chart_series_t * ser4 = lv_chart_add_series(chart, LV_COLOR_BLACK);
        
        /*Set the next points on 'ser1'*/
        while(timer < ms) {
            lv_chart_set_next(chart, ser1, kP);
            lv_chart_set_next(chart, ser2, kI);
            lv_chart_set_next(chart, ser3, kD);
            lv_chart_set_next(chart, ser4, 0);
            timer += 10;
        }

        /*Directly set points on 'ser2'*/
        /*Required after direct set*/
    }
}