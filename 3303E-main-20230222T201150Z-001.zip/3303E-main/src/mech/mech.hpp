#pragma once

#include "main.h"
#include "pros/adi.hpp"
#include "pros/vision.hpp"
#include "constants.hpp"

namespace src::Mech {

    enum class IntakeStates {
        OFF = 0,
        INTAKE = 1,
        OUTTAKE = 2,
        ROLLER = 3,
    };

    enum class ExpansionStates {
        IN = 0,
        OUT = 1,
    };

    enum class FlywheelStates {
        OFF = 0,
        ON = 1,
    };

    enum class IndexerStates {
        IN = 1,
        OUT = 0,
    };

    extern void initialize();
    extern void update();
    extern void act();

    void shoot(int delay);
    void flywheelControlTask(void *);
    void flywheelVelocityTask(void *);
    void setFWSRPM(float rpm, FlywheelStates state);
    void setExpansionState(ExpansionStates state);

    static Motor flywheelMotor = Motor(FLYWHEEL_PORT, false, AbstractMotor::gearset::blue, AbstractMotor::encoderUnits::degrees);
    static Motor intakeMotor = Motor(INTAKE_PORT, false, AbstractMotor::gearset::blue, AbstractMotor::encoderUnits::degrees);

    static pros::ADIDigitalOut indexer = pros::ADIDigitalOut(INDEXER_PORT, static_cast<bool>(IndexerStates::OUT));

    static pros::ADIDigitalOut leftExpansion = pros::ADIDigitalOut(LEFT_EXPANSION_PORT, static_cast<bool>(ExpansionStates::OUT));
    static pros::ADIDigitalOut rightExpansion = pros::ADIDigitalOut(RIGHT_EXPANSION_PORT, static_cast<bool>(ExpansionStates::OUT));
}