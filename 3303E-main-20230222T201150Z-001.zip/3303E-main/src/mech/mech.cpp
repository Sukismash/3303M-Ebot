#include "mech.hpp"

#include "common.h"
#include "okapi/api/control/async/asyncVelIntegratedController.hpp"
#include "okapi/impl/device/button/controllerButton.hpp"
#include "okapi/impl/device/controllerUtil.hpp"
#include "okapi/impl/device/motor/motor.hpp"
#include "pros/rtos.hpp"
#include "constants.hpp"
#include <string>

namespace src::Mech {

    ControllerButton flywheelToggle(ControllerDigital::X);
    ControllerButton indexerToggle(ControllerDigital::L1);
    ControllerButton intakeBtn(ControllerDigital::R1);
    ControllerButton outtakeBtn(ControllerDigital::R2);
    ControllerButton rapidFireTrigger(ControllerDigital::L2);
    ControllerButton roller(ControllerDigital::Y);

    ControllerButton expansionTrigger(ControllerDigital::up);

    IndexerStates currIndexerState = IndexerStates::IN;
    FlywheelStates currFlywheelState = FlywheelStates::OFF;
    IntakeStates currIntakeState = IntakeStates::OFF;
    ExpansionStates currExpansionState = ExpansionStates::IN;

    float flywheelTargetRPM = 0;
    void flywheelVelocityTask(void *) {
        while (true) {
            if (flywheelTargetRPM == 0) {
                pros::delay(10);
                continue;
            }
            float error = flywheelTargetRPM - (flywheelMotor.getActualVelocity() * 5.0f);
            float thresholdRPM = 75.0f; // RPM above/below the target RPM to be considered "on target"
            if (error > (flywheelTargetRPM - thresholdRPM)) {
                flywheelMotor.moveVoltage(12000);
            } else if (error <= -thresholdRPM) {
                flywheelMotor.moveVoltage(0);
            } else { // Within threshold window -> Use Feedforward and P Controller
                flywheelMotor.moveVoltage((flywheelTargetRPM * 4.0f) + (error * 1.0f));
            }
            pros::delay(10);
        }
    }

    void shoot(int delay) {
        indexer.set_value(static_cast<bool>(IndexerStates::OUT));
        pros::delay(100);
        indexer.set_value(static_cast<bool>(IndexerStates::IN));
        pros::delay(delay - 100);
    }



    void setFWSRPM(float rpm, FlywheelStates state) {
        currFlywheelState = state;
        switch (state) {
            case FlywheelStates::OFF:
                flywheelTargetRPM = 0.0f;
                break;
            case FlywheelStates::ON:
                flywheelTargetRPM = rpm;
                break;
        }
    }

    void initialize() {
        leftExpansion.set_value(static_cast<bool>(ExpansionStates::IN));
        rightExpansion.set_value(static_cast<bool>(ExpansionStates::IN));
        flywheelMotor.setBrakeMode(AbstractMotor::brakeMode::coast);
        intakeMotor.setBrakeMode(AbstractMotor::brakeMode::coast); // Set to brake because we might want to hold a frisbee in the intake
        flywheelTargetRPM = 0;
        pros::Task flywheelVelocityTaskHandle(flywheelVelocityTask);

    }

    void update() {
        currIntakeState = IntakeStates::OFF;

        //Flywheel
        if (flywheelToggle.changedToPressed()) {
            if (currFlywheelState == FlywheelStates::OFF) {
                currFlywheelState = FlywheelStates::ON;
            } else {
                currFlywheelState = FlywheelStates::OFF;
            }
        }

        //Indexer
        if (indexerToggle.changedToPressed()) {
            shoot(200);
        }

        if(rapidFireTrigger.changedToPressed()) {
            shoot(300);
            flywheelMotor.moveVoltage(8400);
            shoot(300);
            shoot(300);
            flywheelMotor.moveVoltage(8000);
        }
        //Intake/Outake
        if (intakeBtn.controllerGet() == true) {
            currIntakeState = IntakeStates::INTAKE;
        }

        if (outtakeBtn.controllerGet() == true) {
            currIntakeState = IntakeStates::OUTTAKE;
        }

        if (roller.controllerGet() == true){
            currIntakeState = IntakeStates::ROLLER;
        }

        //Expansion Trigger
        if (expansionTrigger.changedToPressed()) {
            currExpansionState = ExpansionStates::OUT;
        }

    }

    void act() {
        switch (currIntakeState) {
            case IntakeStates::OUTTAKE:
                intakeMotor.moveVoltage(-12000);
                break;
            case IntakeStates::INTAKE:
                intakeMotor.moveVoltage(12000);
                break;
            case IntakeStates::ROLLER:
                intakeMotor.moveVoltage(9000);
                break;
            case IntakeStates::OFF:
                intakeMotor.moveVoltage(0);
                break;
        }

        switch (currFlywheelState) {
            case FlywheelStates::ON:
                flywheelMotor.moveVoltage(7900);
                break;
            case FlywheelStates::OFF:
                flywheelMotor.moveVoltage(0);
                break;
        }

        switch (currIndexerState) {
            case IndexerStates::IN:
                indexer.set_value(static_cast<bool>(IndexerStates::IN));
                break;
            case IndexerStates::OUT:
                indexer.set_value(static_cast<bool>(IndexerStates::OUT));
                break;
        }

        switch (currExpansionState) {
            case ExpansionStates::IN:
                leftExpansion.set_value(static_cast<bool>(ExpansionStates::IN));
                rightExpansion.set_value(static_cast<bool>(ExpansionStates::IN));
                break;
            case ExpansionStates::OUT:
                leftExpansion.set_value(static_cast<bool>(ExpansionStates::OUT));
                rightExpansion.set_value(static_cast<bool>(ExpansionStates::OUT));
                break;
        }
    }
}