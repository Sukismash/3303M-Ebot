#include "chassis/chassis.hpp"
#include "okapi/impl/device/controller.hpp"
#include "pros/misc.h"
#include "pros/misc.hpp"
#include "pros/rtos.hpp"
#include "mech/mech.hpp"
#include <cstdlib>

void on_center_button() {
	static bool pressed = false;
	pressed = !pressed;
	if (pressed) {
		pros::lcd::set_text(2, "I was pressed!");
	} else {
		pros::lcd::clear_line(2);
	}
}


void initialize() {
	pros::lcd::initialize();
	pros::lcd::set_text(1, "Im Gay");

	pros::lcd::register_btn1_cb(on_center_button);
	src::Chassis::initialize();
	src::Mech::initialize();
	src::Mech::indexer.set_value(static_cast<bool>(src::Mech::IndexerStates::IN));
}

void shoot(int ms = 200, int v = 8250) {
        src::Mech::indexer.set_value(static_cast<bool>(src::Mech::IndexerStates::OUT));
        pros::delay(100);
		src::Mech::flywheelMotor.moveVoltage(v);
        src::Mech::indexer.set_value(static_cast<bool>(src::Mech::IndexerStates::IN));
        pros::delay(ms - 100);
		
    }

void nonPIDdrive(int volts, int ms) {
	src::Chassis::left_chassis.moveVoltage(volts);
	src::Chassis::right_chassis.moveVoltage(volts);
	pros::delay(ms);
	src::Chassis::left_chassis.moveVoltage(0);
	src::Chassis::right_chassis.moveVoltage(0);
}

void wp_auton() {

	//Initialize flywheel and indexer; Getting flywheel to speed up
	src::Mech::flywheelMotor.moveVoltage(10325);

	//Spin roller
	src::Mech::intakeMotor.moveVoltage(-8000);
	src::Chassis::movePID(3.25, 3.25, 250);
	pros::delay(50);
	src::Mech::intakeMotor.moveVoltage(0);

	src::Chassis::movePID(-2, -2, 250);
	src::Chassis::gyroPID(-12, 500);
	pros::delay(1500);
	shoot(700, 10600);
	shoot(500);

	//Intake 3 stack 

	src::Chassis::gyroPID(-120, 1000);
	src::Chassis::movePID(24, 24, 1250);
	src::Mech::intakeMotor.moveVoltage(12000);
	nonPIDdrive(-2100, 3200);
	src::Chassis::gyroPID(98);
	shoot(750, 9500);
	shoot(750, 9500);
	shoot();
}

void non_roller_wp_auton() {
	src::Mech::flywheelMotor.moveVoltage(10000);
	src::Mech::intakeMotor.moveVoltage(12000);

	src::Chassis::movePID(20, 20, 1000);
	src::Chassis::gyroPID(-156);
	pros::delay(500);
	shoot(700, 10100);
	shoot(500, 10150);
	src::Mech::intakeMotor.moveVoltage(0);
	shoot(200, 8250);


	src::Mech::intakeMotor.moveVoltage(12000);
	src::Chassis::gyroPID(113);
	src::Chassis::movePID(36, 36, 1500);
	src::Chassis::gyroPID(-89);

	shoot(700, 8450);
	src::Mech::intakeMotor.moveVoltage(0);
	shoot(500, 0);

	src::Chassis::gyroPID(-95);
	src::Chassis::movePID(65, 65, 1850);
	src::Chassis::gyroPID(46);

	src::Mech::intakeMotor.moveVoltage(-8000);
	src::Chassis::movePID(11, 11, 750);
	pros::delay(50);
	src::Mech::intakeMotor.moveVoltage(0);
	src::Chassis::movePID(-5, -5, 150);
}

void disabled() {
	src::Chassis::initialize();
	src::Mech::initialize();
}


void competition_initialize() {
	src::Chassis::initialize();
	src::Mech::initialize();
}


void autonomous() {
	src::Chassis::initialize();
	src::Mech::initialize();
	wp_auton(); 
}


void opcontrol() {
	src::Chassis::initialize();
	src::Mech::initialize();

	while (true) {
		src::Mech::update();
		src::Chassis::update();
		src::Mech::act();
		src::Chassis::act();

		pros::delay(10);
	}
}
